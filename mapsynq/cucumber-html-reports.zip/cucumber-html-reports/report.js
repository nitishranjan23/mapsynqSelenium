$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("GoogleMapRelatedFunctionality.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "###Author: Nitish"
    },
    {
      "line": 2,
      "value": "###Date: 11th Feb 2019"
    }
  ],
  "line": 3,
  "name": "To test Google Map related features of mapsynq home page",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 7216408404,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4237362663,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 113400052,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 4838743312,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 135819605,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Top pannel buttons on the map",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;top-pannel-buttons-on-the-map",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "Google map is loaded",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "verify panel buttons are present on top of the map to show following",
  "rows": [
    {
      "cells": [
        "Traffic Speed"
      ],
      "line": 14
    },
    {
      "cells": [
        "Incidents/Alerts"
      ],
      "line": 15
    },
    {
      "cells": [
        "Parking"
      ],
      "line": 16
    },
    {
      "cells": [
        "Camera"
      ],
      "line": 17
    },
    {
      "cells": [
        "Toll"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "click on \"Incidents\" button to make it active",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "verify incidents are marked on the map",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "click on \"Traffic Speed\" button to make it active",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "verify Live Traffic information is displayed on the map",
  "keyword": "And "
});
formatter.match({
  "location": "GoogleMapsSteps.google_map_is_loaded()"
});
formatter.result({
  "duration": 19316896,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_panel_buttons_are_present_on_top_of_the_map_to_show_following(String\u003e)"
});
formatter.result({
  "duration": 245294695,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Incidents",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_button_to_make_it_active(String)"
});
formatter.result({
  "duration": 41491932,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_incidents_are_marked_on_the_map()"
});
formatter.result({
  "duration": 54676567,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Traffic Speed",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_button_to_make_it_active(String)"
});
formatter.result({
  "duration": 258487782,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_Live_Traffic_information_is_displayed_on_the_map()"
});
formatter.result({
  "duration": 102889414,
  "status": "passed"
});
formatter.after({
  "duration": 1343182062,
  "status": "passed"
});
formatter.before({
  "duration": 3805112774,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 3806522524,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 61683054,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 4760652216,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 146411144,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Zoom bar and direction slider buttons",
  "description": "Here I am checking the presence of zoom bar and four buttons to move the map in four directions",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;zoom-bar-and-direction-slider-buttons",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "Google map is loaded",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "verify following direction slider buttons are present on the map",
  "rows": [
    {
      "cells": [
        "up"
      ],
      "line": 29
    },
    {
      "cells": [
        "down"
      ],
      "line": 30
    },
    {
      "cells": [
        "left"
      ],
      "line": 31
    },
    {
      "cells": [
        "right"
      ],
      "line": 32
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "verify \"zoomin\" and \"zoomout\" buttons are present on the map",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "verify zoombar is present on the map",
  "keyword": "And "
});
formatter.match({
  "location": "GoogleMapsSteps.google_map_is_loaded()"
});
formatter.result({
  "duration": 18692622,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_following_direction_slider_buttons_are_present_on_the_map(String\u003e)"
});
formatter.result({
  "duration": 214468564,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "zoomin",
      "offset": 8
    },
    {
      "val": "zoomout",
      "offset": 21
    }
  ],
  "location": "GoogleMapsSteps.verify_and_buttons_are_present_on_the_map(String,String)"
});
formatter.result({
  "duration": 136261548,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_zoombar_is_present_on_the_map()"
});
formatter.result({
  "duration": 46713743,
  "status": "passed"
});
formatter.after({
  "duration": 1205784866,
  "status": "passed"
});
formatter.before({
  "duration": 3844738523,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4680697353,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 66598162,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 4125278177,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 137328973,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "Functioning of Direction buttons",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;functioning-of-direction-buttons",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "Google map is loaded",
  "keyword": "When "
});
formatter.step({
  "line": 38,
  "name": "click on \"up\" direction button",
  "keyword": "Then "
});
formatter.step({
  "line": 39,
  "name": "verify google map is slided to show upper area into view",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "click on \"down\" direction button",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "verify google map is slided to show lower area into view",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "click on \"left\" direction button",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "verify google map is slided to show left area into view",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "click on \"right\" direction button",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "verify google map is slided to show right area into view",
  "keyword": "And "
});
formatter.match({
  "location": "GoogleMapsSteps.google_map_is_loaded()"
});
formatter.result({
  "duration": 19485341,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "up",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_direction_button(String)"
});
formatter.result({
  "duration": 214445017,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_google_map_is_slided_to_show_upper_area_into_view()"
});
formatter.result({
  "duration": 5082662067,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "down",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_direction_button(String)"
});
formatter.result({
  "duration": 177879060,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_google_map_is_slided_to_show_lower_area_into_view()"
});
formatter.result({
  "duration": 5103819185,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "left",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_direction_button(String)"
});
formatter.result({
  "duration": 175052314,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_google_map_is_slided_to_show_left_area_into_view()"
});
formatter.result({
  "duration": 5071859215,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "right",
      "offset": 10
    }
  ],
  "location": "GoogleMapsSteps.click_on_direction_button(String)"
});
formatter.result({
  "duration": 169245473,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_google_map_is_slided_to_show_right_area_into_view()"
});
formatter.result({
  "duration": 5062719085,
  "status": "passed"
});
formatter.after({
  "duration": 1198808565,
  "status": "passed"
});
formatter.before({
  "duration": 3814176833,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 3995933762,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 53470279,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 5247402981,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 131417684,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "Display of Incidents on Google map",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;display-of-incidents-on-google-map",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 48,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 49,
  "name": "click on \"Incidents\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "verify incident list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 51,
  "name": "verify clicking on any incident displays that incident on the map",
  "keyword": "Then "
});
formatter.step({
  "line": 52,
  "name": "verify \"Incidents\" pannel is active on the top of the map",
  "keyword": "And "
});
formatter.step({
  "line": 53,
  "name": "click on the close button in the popup",
  "keyword": "Then "
});
formatter.step({
  "line": 54,
  "name": "verify information popup is closed",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 192311036,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Incidents",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 154898624,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_incident_list_is_displayed()"
});
formatter.result({
  "duration": 27417374,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_clicking_on_any_incident_displays_that_incident_on_the_map()"
});
formatter.result({
  "duration": 665353718,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Incidents",
      "offset": 8
    }
  ],
  "location": "GoogleMapsSteps.verify_pannel_is_active_on_the_top_of_the_map(String)"
});
formatter.result({
  "duration": 96024806,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.click_on_the_close_button_in_the_popup()"
});
formatter.result({
  "duration": 130513873,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_information_popup_is_closed()"
});
formatter.result({
  "duration": 25703335,
  "status": "passed"
});
formatter.after({
  "duration": 1230376099,
  "status": "passed"
});
formatter.before({
  "duration": 4320458824,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5454602426,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 53449148,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 5221439430,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 157572622,
  "status": "passed"
});
formatter.scenario({
  "line": 56,
  "name": "Display of Cameras on Google map",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;display-of-cameras-on-google-map",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 57,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 58,
  "name": "click on \"Cameras\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 59,
  "name": "verify camera list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 60,
  "name": "verify clicking on any camera displays that camera on the map",
  "keyword": "Then "
});
formatter.step({
  "line": 61,
  "name": "verify \"Camera\" pannel is active on the top of the map",
  "keyword": "And "
});
formatter.step({
  "line": 62,
  "name": "click on the close button in the popup",
  "keyword": "Then "
});
formatter.step({
  "line": 63,
  "name": "verify information popup is closed",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 175243703,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Cameras",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 277205761,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_camera_list_is_displayed()"
});
formatter.result({
  "duration": 50743757,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_clicking_on_any_camera_displays_that_camera_on_the_map()"
});
formatter.result({
  "duration": 32424262311,
  "error_message": "org.openqa.selenium.TimeoutException: Expected condition failed: waiting for visibility of Proxy element for: DefaultElementLocator \u0027By.id: popup_contentDiv\u0027 (tried for 30 second(s) with 500 milliseconds interval)\r\n\tat org.openqa.selenium.support.ui.WebDriverWait.timeoutException(WebDriverWait.java:113)\r\n\tat org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:283)\r\n\tat utils.ActionMethods.sync(ActionMethods.java:76)\r\n\tat steps.GoogleMapsSteps.verify_clicking_on_any_camera_displays_that_camera_on_the_map(GoogleMapsSteps.java:412)\r\n\tat ✽.Then verify clicking on any camera displays that camera on the map(GoogleMapRelatedFunctionality.feature:60)\r\nCaused by: org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"id\",\"selector\":\"popup_contentDiv\"}\n  (Session info: headless chrome\u003d72.0.3626.109)\n  (Driver info: chromedriver\u003d73.0.3683.20 (8e2b610813e167eee3619ac4ce6e42e3ec622017),platform\u003dWindows NT 6.3.9600 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.14.0\u0027, revision: \u0027aacccce0\u0027, time: \u00272018-08-02T20:19:58.91Z\u0027\nSystem info: host: \u0027DELL\u0027, ip: \u0027192.168.0.13\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 73.0.3683.20 (8e2b610813e16..., userDataDir: C:\\Users\\DELL-PC\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:56414}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), rotatable: false, setWindowRect: true, strictFileInteractability: false, takesHeapSnapshot: true, takesScreenshot: true, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unexpectedAlertBehaviour: ignore, unhandledPromptBehavior: ignore, version: 72.0.3626.109, webStorageEnabled: true}\nSession ID: 3c546c9de28d7640debaf84b95eea97c\n*** Element info: {Using\u003did, value\u003dpopup_contentDiv}\r\n\tat sun.reflect.GeneratedConstructorAccessor20.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy17.isDisplayed(Unknown Source)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions.elementIfVisible(ExpectedConditions.java:315)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions.access$100(ExpectedConditions.java:44)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$10.apply(ExpectedConditions.java:301)\r\n\tat org.openqa.selenium.support.ui.ExpectedConditions$10.apply(ExpectedConditions.java:298)\r\n\tat org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:260)\r\n\tat utils.ActionMethods.sync(ActionMethods.java:76)\r\n\tat steps.GoogleMapsSteps.verify_clicking_on_any_camera_displays_that_camera_on_the_map(GoogleMapsSteps.java:412)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.lang.reflect.Method.invoke(Method.java:498)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:40)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:34)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:38)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:300)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat org.junit.runner.JUnitCore.run(JUnitCore.java:137)\r\n\tat org.junit.runner.JUnitCore.run(JUnitCore.java:115)\r\n\tat org.testng.junit.JUnit4TestRunner.start(JUnit4TestRunner.java:82)\r\n\tat org.testng.junit.JUnit4TestRunner.run(JUnit4TestRunner.java:70)\r\n\tat org.testng.TestRunner$1.run(TestRunner.java:570)\r\n\tat org.testng.TestRunner.runJUnitWorkers(TestRunner.java:717)\r\n\tat org.testng.TestRunner.privateRunJUnit(TestRunner.java:601)\r\n\tat org.testng.TestRunner.run(TestRunner.java:502)\r\n\tat org.testng.SuiteRunner.runTest(SuiteRunner.java:455)\r\n\tat org.testng.SuiteRunner.runSequentially(SuiteRunner.java:450)\r\n\tat org.testng.SuiteRunner.privateRun(SuiteRunner.java:415)\r\n\tat org.testng.SuiteRunner.run(SuiteRunner.java:364)\r\n\tat org.testng.SuiteRunnerWorker.runSuite(SuiteRunnerWorker.java:52)\r\n\tat org.testng.SuiteRunnerWorker.run(SuiteRunnerWorker.java:84)\r\n\tat org.testng.TestNG.runSuitesSequentially(TestNG.java:1208)\r\n\tat org.testng.TestNG.runSuitesLocally(TestNG.java:1137)\r\n\tat org.testng.TestNG.runSuites(TestNG.java:1049)\r\n\tat org.testng.TestNG.run(TestNG.java:1017)\r\n\tat org.apache.maven.surefire.testng.TestNGExecutor.run(TestNGExecutor.java:115)\r\n\tat org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.executeMulti(TestNGDirectoryTestSuite.java:212)\r\n\tat org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.execute(TestNGDirectoryTestSuite.java:108)\r\n\tat org.apache.maven.surefire.testng.TestNGProvider.invoke(TestNGProvider.java:111)\r\n\tat org.apache.maven.surefire.booter.ForkedBooter.invokeProviderInSameClassLoader(ForkedBooter.java:203)\r\n\tat org.apache.maven.surefire.booter.ForkedBooter.runSuitesInProcess(ForkedBooter.java:155)\r\n\tat org.apache.maven.surefire.booter.ForkedBooter.main(ForkedBooter.java:103)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "Camera",
      "offset": 8
    }
  ],
  "location": "GoogleMapsSteps.verify_pannel_is_active_on_the_top_of_the_map(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "GoogleMapsSteps.click_on_the_close_button_in_the_popup()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_information_popup_is_closed()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded0.png");
formatter.after({
  "duration": 1849849848,
  "status": "passed"
});
formatter.before({
  "duration": 4189257885,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5146951499,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 56436490,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 4695954047,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 126063652,
  "status": "passed"
});
formatter.scenario({
  "line": 65,
  "name": "Display of Tolls on Google map",
  "description": "",
  "id": "to-test-google-map-related-features-of-mapsynq-home-page;display-of-tolls-on-google-map",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 66,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 67,
  "name": "click on \"Tolls\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "verify Tolls list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 69,
  "name": "verify clicking on any Tolls displays that Tolls on the map",
  "keyword": "Then "
});
formatter.step({
  "line": 70,
  "name": "verify \"Toll\" pannel is active on the top of the map",
  "keyword": "And "
});
formatter.step({
  "line": 71,
  "name": "click on the close button in the popup",
  "keyword": "Then "
});
formatter.step({
  "line": 72,
  "name": "verify information popup is closed",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 147894552,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tolls",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 190372404,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_Tolls_list_is_displayed()"
});
formatter.result({
  "duration": 28706978,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_clicking_on_any_Tolls_displays_that_Tolls_on_the_map()"
});
formatter.result({
  "duration": 5204270667,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Toll",
      "offset": 8
    }
  ],
  "location": "GoogleMapsSteps.verify_pannel_is_active_on_the_top_of_the_map(String)"
});
formatter.result({
  "duration": 84596474,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.click_on_the_close_button_in_the_popup()"
});
formatter.result({
  "duration": 186813916,
  "status": "passed"
});
formatter.match({
  "location": "GoogleMapsSteps.verify_information_popup_is_closed()"
});
formatter.result({
  "duration": 13241990,
  "status": "passed"
});
formatter.after({
  "duration": 1403675734,
  "status": "passed"
});
formatter.uri("HomePage.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Nitish"
    },
    {
      "line": 2,
      "value": "#Date: 10th Feb 2019"
    }
  ],
  "line": 3,
  "name": "To test basic features of mapsynq home page",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4413556663,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 6929681548,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 61099834,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Home Page",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page;home-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "verify page defaults to \"Live\" tab",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 3561040667,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 187616901,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 25
    }
  ],
  "location": "MapsynqHomeSteps.verify_page_defaults_to_tab(String)"
});
formatter.result({
  "duration": 75445475,
  "status": "passed"
});
formatter.after({
  "duration": 1318571510,
  "status": "passed"
});
formatter.before({
  "duration": 4184477414,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 6092913697,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 63301098,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Top right corner links",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page;top-right-corner-links",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "verify following links are present on the top right corner of the page",
  "rows": [
    {
      "cells": [
        "Sign in"
      ],
      "line": 16
    },
    {
      "cells": [
        "Register"
      ],
      "line": 17
    },
    {
      "cells": [
        "Mobile App"
      ],
      "line": 18
    },
    {
      "cells": [
        "Galactio"
      ],
      "line": 19
    },
    {
      "cells": [
        "SG GPS Navigation"
      ],
      "line": 20
    },
    {
      "cells": [
        "Legend"
      ],
      "line": 21
    },
    {
      "cells": [
        "Calendar"
      ],
      "line": 22
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_following_links_are_present_on_the_top_right_corner_of_the_page(String\u003e)"
});
formatter.result({
  "duration": 265895761,
  "status": "passed"
});
formatter.after({
  "duration": 1374319123,
  "status": "passed"
});
formatter.before({
  "duration": 7130405803,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4201978238,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 51601078,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Top Left Tabs",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page;top-left-tabs",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "verify following tabs are present on the top left corner",
  "rows": [
    {
      "cells": [
        "Directions"
      ],
      "line": 26
    },
    {
      "cells": [
        "Personal"
      ],
      "line": 27
    },
    {
      "cells": [
        "Live"
      ],
      "line": 28
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_following_tabs_are_present_on_the_top_left_corner(String\u003e)"
});
formatter.result({
  "duration": 160197112,
  "status": "passed"
});
formatter.after({
  "duration": 1307047181,
  "status": "passed"
});
formatter.before({
  "duration": 4157246598,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4971904618,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 60095803,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Live Tab",
  "description": "Verifications of Live Tab and its sub-tabs",
  "id": "to-test-basic-features-of-mapsynq-home-page;live-tab",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "verify following sub tabs are present",
  "rows": [
    {
      "cells": [
        "Incidents"
      ],
      "line": 35
    },
    {
      "cells": [
        "Cameras"
      ],
      "line": 36
    },
    {
      "cells": [
        "Tolls"
      ],
      "line": 37
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 183210149,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_following_sub_tabs_are_present(String\u003e)"
});
formatter.result({
  "duration": 231886070,
  "status": "passed"
});
formatter.after({
  "duration": 1206807010,
  "status": "passed"
});
formatter.before({
  "duration": 4154518264,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 3771831805,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 100253453,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Incidents Sub-tab of Live Tab",
  "description": "  Verifications of Incident sub-tab of Live tab",
  "id": "to-test-basic-features-of-mapsynq-home-page;incidents-sub-tab-of-live-tab",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 42,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "click on \"Incidents\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "verify incident list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "verify \"Search incident location\" textbox is present",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "verify \"Date\" dropdown is present",
  "keyword": "And "
});
formatter.step({
  "line": 47,
  "name": "click on \"Date\" dropdown",
  "keyword": "Then "
});
formatter.step({
  "line": 48,
  "name": "verify past 2 dates are present in the \"Date\" dropdown",
  "keyword": "And "
});
formatter.step({
  "line": 49,
  "name": "verify the search functionality in Incident sub-tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 138446510,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Incidents",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 254670287,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_incident_list_is_displayed()"
});
formatter.result({
  "duration": 35461704,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Search incident location",
      "offset": 8
    }
  ],
  "location": "MapsynqHomeSteps.verify_textbox_is_present(String)"
});
formatter.result({
  "duration": 98388478,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Date",
      "offset": 8
    }
  ],
  "location": "MapsynqHomeSteps.verify_dropdown_is_present(String)"
});
formatter.result({
  "duration": 113868560,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Date",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_dropdown(String)"
});
formatter.result({
  "duration": 353709001,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 12
    },
    {
      "val": "Date",
      "offset": 40
    }
  ],
  "location": "MapsynqHomeSteps.verify_past_dates_are_present_in_the_dropdown(int,String)"
});
formatter.result({
  "duration": 164289310,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_the_search_functionality_in_Incident_sub_tab()"
});
formatter.result({
  "duration": 1186944929,
  "status": "passed"
});
formatter.after({
  "duration": 1143475725,
  "status": "passed"
});
formatter.before({
  "duration": 4198794075,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4598872079,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 54177268,
  "status": "passed"
});
formatter.scenario({
  "line": 51,
  "name": "Cameras Sub-tab of Live",
  "description": "  Verifications of Cameras sub-tab of Live tab",
  "id": "to-test-basic-features-of-mapsynq-home-page;cameras-sub-tab-of-live",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 55,
  "name": "click on \"Cameras\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "verify camera list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 57,
  "name": "verify \"Search camera location\" textbox is present",
  "keyword": "And "
});
formatter.step({
  "line": 58,
  "name": "verify search functionality on Cameras sub-tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 158311608,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Cameras",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 299807647,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_camera_list_is_displayed()"
});
formatter.result({
  "duration": 38639226,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Search camera location",
      "offset": 8
    }
  ],
  "location": "MapsynqHomeSteps.verify_textbox_is_present(String)"
});
formatter.result({
  "duration": 42486304,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_search_functionality_on_Cameras_sub_tab()"
});
formatter.result({
  "duration": 2731985689,
  "status": "passed"
});
formatter.after({
  "duration": 1197034152,
  "status": "passed"
});
formatter.before({
  "duration": 4165504654,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4199959911,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 50359169,
  "status": "passed"
});
formatter.scenario({
  "line": 60,
  "name": "Tolls Sub-tab of Live Tab",
  "description": " Verifications of Tolls sub-tab of Live tab",
  "id": "to-test-basic-features-of-mapsynq-home-page;tolls-sub-tab-of-live-tab",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 63,
  "name": "user clicks on \"Live\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 64,
  "name": "click on \"Tolls\" sub-tab",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "verify Tolls list is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 66,
  "name": "verify \"Search gantry location\" textbox is present",
  "keyword": "And "
});
formatter.step({
  "line": 67,
  "name": "verify search functionality on Tolls tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Live",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 284325753,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Tolls",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_sub_tab(String)"
});
formatter.result({
  "duration": 243970074,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_Tolls_list_is_displayed()"
});
formatter.result({
  "duration": 90021747,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Search gantry location",
      "offset": 8
    }
  ],
  "location": "MapsynqHomeSteps.verify_textbox_is_present(String)"
});
formatter.result({
  "duration": 68074927,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_search_functionality_on_Tolls_tab()"
});
formatter.result({
  "duration": 3400889440,
  "status": "passed"
});
formatter.after({
  "duration": 1486453118,
  "status": "passed"
});
formatter.before({
  "duration": 4371954850,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4498840201,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 56294005,
  "status": "passed"
});
formatter.scenario({
  "line": 69,
  "name": "Personal Tab",
  "description": "Before sign in",
  "id": "to-test-basic-features-of-mapsynq-home-page;personal-tab",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 72,
  "name": "user clicks on \"Personal\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 73,
  "name": "verify following buttons are present",
  "rows": [
    {
      "cells": [
        "Sign in"
      ],
      "line": 74
    },
    {
      "cells": [
        "Register"
      ],
      "line": 75
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Personal",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 222086044,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_following_buttons_are_present(String\u003e)"
});
formatter.result({
  "duration": 325459060,
  "status": "passed"
});
formatter.after({
  "duration": 1239497513,
  "status": "passed"
});
formatter.before({
  "duration": 4323188969,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 6421195275,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 57213513,
  "status": "passed"
});
formatter.scenario({
  "line": 77,
  "name": "Directions Tab",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page;directions-tab",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 78,
  "name": "user clicks on \"Directions\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 79,
  "name": "verify To/Origin and From/Destination textboxes are present",
  "keyword": "Then "
});
formatter.step({
  "line": 80,
  "name": "verify following checkboxes are present",
  "rows": [
    {
      "cells": [
        "Traffic aware"
      ],
      "line": 81
    },
    {
      "cells": [
        "Toll Aware"
      ],
      "line": 82
    },
    {
      "cells": [
        "Fastest"
      ],
      "line": 83
    },
    {
      "cells": [
        "Shortest"
      ],
      "line": 84
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 85,
  "name": "verify swap origin destination button is present",
  "keyword": "Then "
});
formatter.step({
  "line": 86,
  "name": "Type \"US\" in Destination textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 87,
  "name": "verify search auto-complete suggestions are displayed",
  "keyword": "And "
});
formatter.step({
  "line": 88,
  "name": "select one of the suggestions",
  "keyword": "Then "
});
formatter.step({
  "line": 89,
  "name": "verify Destination textbox is filled",
  "keyword": "And "
});
formatter.step({
  "line": 90,
  "name": "verify clicking on swap origin destination button swaps origin and destination",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Directions",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 199857878,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_To_Origin_and_From_Destination_textboxes_are_present()"
});
formatter.result({
  "duration": 211785511,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_following_checkboxes_are_present(String\u003e)"
});
formatter.result({
  "duration": 203487003,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_swap_origin_destination_button_is_present()"
});
formatter.result({
  "duration": 97418255,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "US",
      "offset": 6
    }
  ],
  "location": "MapsynqHomeSteps.type_in_Destination_textbox(String)"
});
formatter.result({
  "duration": 116596290,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_search_auto_complete_suggestions_are_displayed()"
});
formatter.result({
  "duration": 1115838587,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.select_one_of_the_suggestions()"
});
formatter.result({
  "duration": 145088334,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_Destination_textbox_is_filled()"
});
formatter.result({
  "duration": 59210105,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_clicking_on_swap_origin_destination_button_swaps_origin_and_destination()"
});
formatter.result({
  "duration": 313210837,
  "status": "passed"
});
formatter.after({
  "duration": 1174007228,
  "status": "passed"
});
formatter.before({
  "duration": 4202784845,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5441772191,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 86542954,
  "status": "passed"
});
formatter.scenario({
  "line": 92,
  "name": "Get Directions Alert",
  "description": "",
  "id": "to-test-basic-features-of-mapsynq-home-page;get-directions-alert",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 93,
  "name": "user clicks on \"Directions\" tab",
  "keyword": "When "
});
formatter.step({
  "line": 94,
  "name": "verify To/Origin and From/Destination textboxes are present",
  "keyword": "Then "
});
formatter.step({
  "line": 95,
  "name": "Type \"US\" in Destination textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 96,
  "name": "verify search auto-complete suggestions are displayed",
  "keyword": "And "
});
formatter.step({
  "line": 97,
  "name": "select one of the suggestions",
  "keyword": "Then "
});
formatter.step({
  "line": 98,
  "name": "verify Destination textbox is filled",
  "keyword": "And "
});
formatter.step({
  "line": 99,
  "name": "click on \"Get Directions\" button",
  "keyword": "Then "
});
formatter.step({
  "line": 100,
  "name": "verify Alert is displayed with message as \"Please grant permission to you use the location service on your browser to use your \u0027Current location\u0027.\"",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "Directions",
      "offset": 16
    }
  ],
  "location": "MapsynqHomeSteps.user_clicks_on_tab(String)"
});
formatter.result({
  "duration": 246476833,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_To_Origin_and_From_Destination_textboxes_are_present()"
});
formatter.result({
  "duration": 79304024,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "US",
      "offset": 6
    }
  ],
  "location": "MapsynqHomeSteps.type_in_Destination_textbox(String)"
});
formatter.result({
  "duration": 247849754,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_search_auto_complete_suggestions_are_displayed()"
});
formatter.result({
  "duration": 1629980161,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.select_one_of_the_suggestions()"
});
formatter.result({
  "duration": 147317973,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_Destination_textbox_is_filled()"
});
formatter.result({
  "duration": 53381528,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Get Directions",
      "offset": 10
    }
  ],
  "location": "MapsynqHomeSteps.click_on_button(String)"
});
formatter.result({
  "duration": 193559586,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Please grant permission to you use the location service on your browser to use your \u0027Current location\u0027.",
      "offset": 43
    }
  ],
  "location": "MapsynqHomeSteps.verify_Alert_is_displayed_with_message_as(String)"
});
formatter.result({
  "duration": 6097244,
  "status": "passed"
});
formatter.after({
  "duration": 1189784958,
  "status": "passed"
});
formatter.uri("PageNavigation.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Nitish"
    },
    {
      "line": 2,
      "value": "#Date: 12th Feb 2019"
    }
  ],
  "line": 4,
  "name": "To test navigation of different links on mapsynq home page",
  "description": "I am only checking the navigation here. I am not checking the form fields of Sign in and Register page",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4247602821,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4563388640,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 52402854,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Verify navigation of Sign in link",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-navigation-of-sign-in-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "user clicks on \"Sign in\" link",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "verify Sign in page is opened",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Sign in",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 2106535444,
  "status": "passed"
});
formatter.match({
  "location": "PageNavigation.verify_Sign_in_page_is_opened()"
});
formatter.result({
  "duration": 80809167,
  "status": "passed"
});
formatter.after({
  "duration": 1096967256,
  "status": "passed"
});
formatter.before({
  "duration": 4314968950,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5022431025,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 48692223,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "Verify navigation of Register link",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-navigation-of-register-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "user clicks on \"Register\" link",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "verify \"Create your mapSYNQ account\" page is opened",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Register",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 2109315700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Create your mapSYNQ account",
      "offset": 8
    }
  ],
  "location": "PageNavigation.verify_page_is_opened(String)"
});
formatter.result({
  "duration": 39853965,
  "status": "passed"
});
formatter.after({
  "duration": 914589676,
  "status": "passed"
});
formatter.before({
  "duration": 4096748096,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5450932850,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 46079204,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Verify navigation of Mobile App link",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-navigation-of-mobile-app-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "user clicks on \"Mobile App\" link",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "verify mapsynq mobile information page is opened in new browser tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Mobile App",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 205571139,
  "status": "passed"
});
formatter.match({
  "location": "PageNavigation.verify_mapsynq_mobile_information_page_is_opened_in_new_browser_tab()"
});
formatter.result({
  "duration": 1100499179,
  "status": "passed"
});
formatter.after({
  "duration": 1645114899,
  "status": "passed"
});
formatter.before({
  "duration": 4952471199,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5337013576,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 56262611,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Verify navigation of Galactio link",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-navigation-of-galactio-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "user clicks on \"Galactio\" link",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "verify Galactio page is opened in new browser tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Galactio",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 270765588,
  "status": "passed"
});
formatter.match({
  "location": "PageNavigation.verify_Galactio_page_is_opened_in_new_browser_tab()"
});
formatter.result({
  "duration": 1171815021,
  "status": "passed"
});
formatter.after({
  "duration": 1364976738,
  "status": "passed"
});
formatter.before({
  "duration": 4162144196,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 5541772675,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 59219161,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Verify navigation of SG GPS Navigation link",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-navigation-of-sg-gps-navigation-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "user clicks on \"SG GPS Navigation\" link",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "verify Google Play page is opened in new browser tab",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "SG GPS Navigation",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 316663064,
  "status": "passed"
});
formatter.match({
  "location": "PageNavigation.verify_Google_Play_page_is_opened_in_new_browser_tab()"
});
formatter.result({
  "duration": 2358444795,
  "status": "passed"
});
formatter.after({
  "duration": 1169659643,
  "status": "passed"
});
formatter.before({
  "duration": 4305840894,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4615157560,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 73137953,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Verify Legend link functionality",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-legend-link-functionality",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "user clicks on \"Legend\" link",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "verify \"Legend\" popup is displayed",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Legend",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 486568433,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Legend",
      "offset": 8
    }
  ],
  "location": "PageNavigation.verify_popup_is_displayed(String)"
});
formatter.result({
  "duration": 69897640,
  "status": "passed"
});
formatter.after({
  "duration": 1284047426,
  "status": "passed"
});
formatter.before({
  "duration": 4492246072,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 8,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4333068691,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 51668093,
  "status": "passed"
});
formatter.scenario({
  "line": 35,
  "name": "Verify Calendar link functionality",
  "description": "",
  "id": "to-test-navigation-of-different-links-on-mapsynq-home-page;verify-calendar-link-functionality",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 36,
  "name": "user clicks on \"Calendar\" link",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "verify \"My Events\" popup is displayed",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Calendar",
      "offset": 16
    }
  ],
  "location": "PageNavigation.user_clicks_on_link(String)"
});
formatter.result({
  "duration": 497391811,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "My Events",
      "offset": 8
    }
  ],
  "location": "PageNavigation.verify_popup_is_displayed(String)"
});
formatter.result({
  "duration": 80668493,
  "status": "passed"
});
formatter.after({
  "duration": 1185753132,
  "status": "passed"
});
formatter.uri("SearchFunctionality.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "###Author: Nitish"
    },
    {
      "line": 2,
      "value": "###Date: 17th Feb 2019"
    }
  ],
  "line": 3,
  "name": "To test search related functionality on mapsynq home page",
  "description": "",
  "id": "to-test-search-related-functionality-on-mapsynq-home-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4620352806,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 4734371095,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 53193159,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 4669528630,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 176680018,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Search",
  "description": "",
  "id": "to-test-search-related-functionality-on-mapsynq-home-page;search",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "search text box is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "type \"US\" in the search text box",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "verify global search auto-complete suggestions are displayed",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "select one of the global search suggestions",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "verify global search result is displayed",
  "keyword": "And "
});
formatter.match({
  "location": "Search.search_text_box_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 39110149,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "US",
      "offset": 6
    }
  ],
  "location": "Search.type_in_the_search_text_box(String)"
});
formatter.result({
  "duration": 105923849,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_auto_complete_suggestions_are_displayed()"
});
formatter.result({
  "duration": 641116281,
  "status": "passed"
});
formatter.match({
  "location": "Search.select_one_of_the_global_search_suggestions()"
});
formatter.result({
  "duration": 178686270,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_result_is_displayed()"
});
formatter.result({
  "duration": 591016722,
  "status": "passed"
});
formatter.after({
  "duration": 1119718267,
  "status": "passed"
});
formatter.before({
  "duration": 4198508502,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 7285110625,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 53643555,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 5295405120,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 126390883,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Search result context menu",
  "description": "",
  "id": "to-test-search-related-functionality-on-mapsynq-home-page;search-result-context-menu",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "search text box is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "type \"US\" in the search text box",
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "verify global search auto-complete suggestions are displayed",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "select one of the global search suggestions",
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "verify global search result is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "click on triangle icon beside any search result",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "verify context menu is opened",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "verify following options are present in the context menu",
  "rows": [
    {
      "cells": [
        "To Here"
      ],
      "line": 27
    },
    {
      "cells": [
        "From Here"
      ],
      "line": 28
    },
    {
      "cells": [
        "Zoom In"
      ],
      "line": 29
    },
    {
      "cells": [
        "Whats Nearby"
      ],
      "line": 30
    },
    {
      "cells": [
        "Add To"
      ],
      "line": 31
    },
    {
      "cells": [
        "My Places"
      ],
      "line": 32
    },
    {
      "cells": [
        "Calendar"
      ],
      "line": 33
    },
    {
      "cells": [
        "Share using"
      ],
      "line": 34
    },
    {
      "cells": [
        "Email"
      ],
      "line": 35
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "verify fbShare icon is present",
  "keyword": "Then "
});
formatter.match({
  "location": "Search.search_text_box_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 43788587,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "US",
      "offset": 6
    }
  ],
  "location": "Search.type_in_the_search_text_box(String)"
});
formatter.result({
  "duration": 122887941,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_auto_complete_suggestions_are_displayed()"
});
formatter.result({
  "duration": 1126292472,
  "status": "passed"
});
formatter.match({
  "location": "Search.select_one_of_the_global_search_suggestions()"
});
formatter.result({
  "duration": 136673304,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_result_is_displayed()"
});
formatter.result({
  "duration": 1649959367,
  "status": "passed"
});
formatter.match({
  "location": "Search.click_on_triangle_icon_beside_any_search_result()"
});
formatter.result({
  "duration": 299832400,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_context_menu_is_opened()"
});
formatter.result({
  "duration": 54441105,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_following_options_are_present_in_the_context_menu(String\u003e)"
});
formatter.result({
  "duration": 393046159,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_fbShare_icon_is_present()"
});
formatter.result({
  "duration": 73724795,
  "status": "passed"
});
formatter.after({
  "duration": 1123501348,
  "status": "passed"
});
formatter.before({
  "duration": 4303572011,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Page Launch",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "open the mapsync page with given URL",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "verify mapsync page is loaded properly",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Galactio popup is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "close the Galactio popup",
  "keyword": "Then "
});
formatter.match({
  "location": "MapsynqHomeSteps.open_the_mapsync_page_with_given_URL()"
});
formatter.result({
  "duration": 6014124669,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.verify_mapsync_page_is_loaded_properly()"
});
formatter.result({
  "duration": 47889239,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.galactio_popup_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 5213201901,
  "status": "passed"
});
formatter.match({
  "location": "MapsynqHomeSteps.close_the_Galactio_popup()"
});
formatter.result({
  "duration": 135311250,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Informations in Search Information popup on map",
  "description": "",
  "id": "to-test-search-related-functionality-on-mapsynq-home-page;informations-in-search-information-popup-on-map",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "search text box is displayed on the page",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "type \"US\" in the search text box",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "verify global search auto-complete suggestions are displayed",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "select one of the global search suggestions",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "verify global search result is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "verify clicking on any global search result displays that on map",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "verify following category-wise links are present in the information popup",
  "rows": [
    {
      "cells": [
        "Category",
        "Links"
      ],
      "line": 46
    },
    {
      "cells": [
        "Route",
        "From Here,To Here"
      ],
      "line": 47
    },
    {
      "cells": [
        "See",
        "Zoom in,Nearby,Street View"
      ],
      "line": 48
    },
    {
      "cells": [
        "Add to my",
        "Calendar,Places"
      ],
      "line": 49
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "Search.search_text_box_is_displayed_on_the_page()"
});
formatter.result({
  "duration": 38319844,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "US",
      "offset": 6
    }
  ],
  "location": "Search.type_in_the_search_text_box(String)"
});
formatter.result({
  "duration": 111059323,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_auto_complete_suggestions_are_displayed()"
});
formatter.result({
  "duration": 1130732430,
  "status": "passed"
});
formatter.match({
  "location": "Search.select_one_of_the_global_search_suggestions()"
});
formatter.result({
  "duration": 132615518,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_global_search_result_is_displayed()"
});
formatter.result({
  "duration": 630708280,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_clicking_on_any_global_search_result_displays_that_on_map()"
});
formatter.result({
  "duration": 639254324,
  "status": "passed"
});
formatter.match({
  "location": "Search.verify_following_category_wise_links_are_present_in_the_information_popup(DataTable)"
});
formatter.result({
  "duration": 376712982,
  "status": "passed"
});
formatter.after({
  "duration": 1181535957,
  "status": "passed"
});
});